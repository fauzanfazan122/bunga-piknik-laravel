<?php

use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, "index"]);

Route::get('produk', function(){
   return view('produk', [
      'title' => 'Produk'
   ]);
});

Route::get('riwayat', function(){
   return view('riwayat', [
      'title' => 'Riwayat'
   ]);
});

Route::get('tentang', function(){
   return view('tentang', [
      'title' => 'Tentang'
   ]);
});
