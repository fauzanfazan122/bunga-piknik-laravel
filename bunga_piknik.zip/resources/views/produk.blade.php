@extends('layout.app')

@section('content')

    <h1>Selamat Datang di Produk</h1>

@endsection
